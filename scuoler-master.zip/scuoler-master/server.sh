#tr -d "\r" < server.sh > server1.sh
#!/bin/bash
cd /home/mathew/javascript/ischools-react/
npm run dev
